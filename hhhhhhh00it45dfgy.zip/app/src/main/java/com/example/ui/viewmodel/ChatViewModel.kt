package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entities.CallEntity
import com.example.data.local.entities.ChatEntity
import com.example.data.local.entities.LegendConfigEntity
import com.example.data.local.entities.MessageEntity
import com.example.data.local.entities.StatusEntity
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    AUTH_WELCOME,
    AUTH_PHONE,
    AUTH_OTP,
    HOME,
    CHAT_DETAIL,
    ACTIVE_CALL,
    STATUS_VIEWER,
    STATUS_CREATOR,
    LEGEND_FEATURES,
    NEW_CHAT,
    NEW_GROUP,
    SETTINGS,
    PROFILE,
    ARCHIVED_CHATS
}

data class ActiveCallState(
    val callId: String = "",
    val contactId: String = "",
    val contactName: String = "",
    val contactAvatarRes: Int? = null,
    val isVideo: Boolean = false,
    val isIncoming: Boolean = false,
    val isConnected: Boolean = false,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isVideoOff: Boolean = false,
    val isFrontCamera: Boolean = true
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = ChatRepository(db)

    val activeChats: StateFlow<List<ChatEntity>> = repository.activeChats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val groupChats: StateFlow<List<ChatEntity>> = repository.groupChats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedChats: StateFlow<List<ChatEntity>> = repository.archivedChats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val calls: StateFlow<List<CallEntity>> = repository.allCalls
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val statuses: StateFlow<List<StatusEntity>> = repository.allStatuses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val legendConfig: StateFlow<LegendConfigEntity?> = repository.legendConfig
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _selectedChatId = MutableStateFlow<String?>(null)
    val selectedChatId: StateFlow<String?> = _selectedChatId.asStateFlow()

    private val _currentMessages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val currentMessages: StateFlow<List<MessageEntity>> = _currentMessages.asStateFlow()

    private val _currentChat = MutableStateFlow<ChatEntity?>(null)
    val currentChat: StateFlow<ChatEntity?> = _currentChat.asStateFlow()

    private val _activeCall = MutableStateFlow<ActiveCallState?>(null)
    val activeCall: StateFlow<ActiveCallState?> = _activeCall.asStateFlow()

    private val _selectedStatus = MutableStateFlow<StatusEntity?>(null)
    val selectedStatus: StateFlow<StatusEntity?> = _selectedStatus.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearchOpen = MutableStateFlow(false)
    val isSearchOpen: StateFlow<Boolean> = _isSearchOpen.asStateFlow()

    private var callTimerJob: Job? = null
    private var messagesObservationJob: Job? = null
    private var chatObservationJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureInitialDataSeeded()
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun openChat(chatId: String) {
        _selectedChatId.value = chatId
        _currentScreen.value = AppScreen.CHAT_DETAIL

        messagesObservationJob?.cancel()
        messagesObservationJob = viewModelScope.launch {
            repository.getMessagesForChat(chatId).collect { msgs ->
                _currentMessages.value = msgs
            }
        }

        chatObservationJob?.cancel()
        chatObservationJob = viewModelScope.launch {
            repository.getChatByIdFlow(chatId).collect { chat ->
                _currentChat.value = chat
            }
        }

        viewModelScope.launch {
            repository.clearUnread(chatId)
        }
    }

    fun closeChat() {
        _selectedChatId.value = null
        _currentScreen.value = AppScreen.HOME
        messagesObservationJob?.cancel()
        chatObservationJob?.cancel()
    }

    fun sendMessage(
        text: String,
        messageType: String = "TEXT",
        mediaDuration: Int = 0,
        fileName: String? = null,
        replyToId: String? = null,
        replyToText: String? = null
    ) {
        val chatId = _selectedChatId.value ?: return
        if (text.isBlank() && messageType == "TEXT") return

        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                text = text,
                messageType = messageType,
                mediaDuration = mediaDuration,
                fileName = fileName,
                replyToId = replyToId,
                replyToText = replyToText
            )
        }
    }

    fun setReaction(messageId: String, reaction: String?) {
        viewModelScope.launch {
            repository.setReaction(messageId, reaction)
        }
    }

    fun toggleStarMessage(messageId: String) {
        viewModelScope.launch {
            repository.toggleStarMessage(messageId)
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            repository.deleteMessage(messageId)
        }
    }

    fun clearChat(chatId: String) {
        viewModelScope.launch {
            repository.clearChatMessages(chatId)
        }
    }

    fun togglePinChat(chatId: String) {
        viewModelScope.launch {
            repository.togglePin(chatId)
        }
    }

    fun toggleArchiveChat(chatId: String) {
        viewModelScope.launch {
            repository.toggleArchive(chatId)
        }
    }

    fun toggleMuteChat(chatId: String) {
        viewModelScope.launch {
            repository.toggleMute(chatId)
        }
    }

    fun deleteChat(chatId: String) {
        viewModelScope.launch {
            repository.deleteChat(chatId)
            if (_selectedChatId.value == chatId) {
                closeChat()
            }
        }
    }

    // Call management
    fun startCall(
        contactId: String,
        contactName: String,
        contactAvatarRes: Int?,
        isVideo: Boolean
    ) {
        val callId = "call_${System.currentTimeMillis()}"
        _activeCall.value = ActiveCallState(
            callId = callId,
            contactId = contactId,
            contactName = contactName,
            contactAvatarRes = contactAvatarRes,
            isVideo = isVideo,
            isIncoming = false,
            isConnected = false,
            durationSeconds = 0
        )
        _currentScreen.value = AppScreen.ACTIVE_CALL

        // Simulate connecting and answer after 2.5 seconds
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            delay(2500)
            _activeCall.value = _activeCall.value?.copy(isConnected = true)
            while (true) {
                delay(1000)
                _activeCall.value = _activeCall.value?.let { it.copy(durationSeconds = it.durationSeconds + 1) }
            }
        }
    }

    fun endCall() {
        val call = _activeCall.value
        callTimerJob?.cancel()
        callTimerJob = null
        if (call != null) {
            viewModelScope.launch {
                repository.addCall(
                    contactId = call.contactId,
                    contactName = call.contactName,
                    contactAvatarRes = call.contactAvatarRes,
                    callType = if (call.isVideo) "VIDEO" else "VOICE",
                    direction = if (call.isIncoming) "INCOMING" else "OUTGOING",
                    durationSeconds = call.durationSeconds
                )
            }
        }
        _activeCall.value = null
        _currentScreen.value = if (_selectedChatId.value != null) AppScreen.CHAT_DETAIL else AppScreen.HOME
    }

    fun toggleMuteCall() {
        _activeCall.value = _activeCall.value?.let { it.copy(isMuted = !it.isMuted) }
    }

    fun toggleSpeaker() {
        _activeCall.value = _activeCall.value?.let { it.copy(isSpeakerOn = !it.isSpeakerOn) }
    }

    fun toggleVideoOff() {
        _activeCall.value = _activeCall.value?.let { it.copy(isVideoOff = !it.isVideoOff) }
    }

    fun switchCamera() {
        _activeCall.value = _activeCall.value?.let { it.copy(isFrontCamera = !it.isFrontCamera) }
    }

    // Status management
    fun openStatus(status: StatusEntity) {
        _selectedStatus.value = status
        _currentScreen.value = AppScreen.STATUS_VIEWER
        viewModelScope.launch {
            repository.markStatusViewed(status.id)
        }
    }

    fun closeStatus() {
        _selectedStatus.value = null
        _currentScreen.value = AppScreen.HOME
    }

    fun addStatus(text: String, colorHex: String) {
        viewModelScope.launch {
            repository.addStatus(text, colorHex)
            _currentScreen.value = AppScreen.HOME
        }
    }

    // Search and filters
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleSearch() {
        _isSearchOpen.value = !_isSearchOpen.value
        if (!_isSearchOpen.value) {
            _searchQuery.value = ""
        }
    }

    // Legend Settings updates
    fun updateLegendConfig(config: LegendConfigEntity) {
        viewModelScope.launch {
            repository.updateConfig(config)
        }
    }

    // Create chat or group
    fun createChat(name: String, phone: String) {
        viewModelScope.launch {
            val chatId = repository.createNewChat(name, phone, isGroup = false)
            openChat(chatId)
        }
    }

    fun createGroup(name: String, membersCount: Int) {
        viewModelScope.launch {
            val chatId = repository.createNewChat(name, "", isGroup = true, membersCount = membersCount)
            openChat(chatId)
        }
    }

    fun clearAllCalls() {
        viewModelScope.launch {
            repository.clearAllCalls()
        }
    }
}
