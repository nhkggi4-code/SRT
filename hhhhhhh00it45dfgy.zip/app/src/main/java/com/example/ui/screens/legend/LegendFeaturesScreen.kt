package com.example.ui.screens.legend

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.LegendAvatar
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.DividerColor
import com.example.ui.theme.LegendGold
import com.example.ui.theme.LegendGoldBright
import com.example.ui.theme.LegendGoldDark
import com.example.ui.theme.LegendGoldLight
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueAccent
import com.example.ui.theme.RoyalBlueMedium
import com.example.ui.theme.RoyalMidnight
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TopBarSurface
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegendFeaturesScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val config by viewModel.legendConfig.collectAsStateWithLifecycle()

    var hideOnline by remember(config) { mutableStateOf(config?.hideOnlineStatus ?: false) }
    var hideBlueTicks by remember(config) { mutableStateOf(config?.hideBlueTicks ?: false) }
    var hideSecondTick by remember(config) { mutableStateOf(config?.hideSecondTick ?: false) }
    var antiDelete by remember(config) { mutableStateOf(config?.antiDeleteMessages ?: true) }
    var autoReply by remember(config) { mutableStateOf(config?.autoReplyEnabled ?: false) }
    var autoReplyText by remember(config) { mutableStateOf(config?.autoReplyText ?: "مرحباً، أنا غير متاح حالياً عبر واتساب الاسطورة محمد!") }
    var securityLock by remember(config) { mutableStateOf(config?.securityLockEnabled ?: false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "👑 إضافات الاسطورة محمد",
                            color = LegendGoldBright,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.HOME) },
                        modifier = Modifier.testTag("btn_back_from_legend")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = LegendGoldBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = TopBarSurface
                )
            )
        },
        containerColor = RoyalNavyDark,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(RoyalNavyDark)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Brand Badge
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, LegendGold.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        LegendAvatar(
                            name = "الاسطورة محمد",
                            avatarRes = R.drawable.img_legend_avatar,
                            size = 64.dp,
                            isVip = true
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = "واتساب الاسطورة محمد 👑",
                                color = LegendGoldBright,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "الإصدار الملكي V12.0 المطوّر",
                                color = RoyalBlueAccent,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "أعلى درجات الخصوصية والتخصيص الملكي الفاخر",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Section 1: Privacy & Security
            item {
                Text(
                    text = "🛡️ الحماية والخصوصية الملكية",
                    color = LegendGoldBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        FeatureSwitchRow(
                            title = "تجميد آخر ظهور (إخفاء متصل الآن)",
                            subtitle = "لن يتمكن أحد من رؤية وقت اتصالك الأخير",
                            icon = Icons.Default.VisibilityOff,
                            checked = hideOnline,
                            onCheckedChange = {
                                hideOnline = it
                                config?.let { c -> viewModel.updateLegendConfig(c.copy(hideOnlineStatus = it)) }
                            }
                        )

                        HorizontalDivider(color = DividerColor, modifier = Modifier.padding(vertical = 10.dp))

                        FeatureSwitchRow(
                            title = "منع حذف الرسائل والحالات",
                            subtitle = "اقرأ جميع الرسائل حتى لو قام الطرف الآخر بحذفها",
                            icon = Icons.Default.Shield,
                            checked = antiDelete,
                            onCheckedChange = {
                                antiDelete = it
                                config?.let { c -> viewModel.updateLegendConfig(c.copy(antiDeleteMessages = it)) }
                            }
                        )

                        HorizontalDivider(color = DividerColor, modifier = Modifier.padding(vertical = 10.dp))

                        FeatureSwitchRow(
                            title = "إخفاء صحين القراءة الأزرق (Blue Ticks)",
                            subtitle = "تظهر الصحين زرقاء فقط بعد قيامك بالرد",
                            icon = Icons.Default.DoneAll,
                            checked = hideBlueTicks,
                            onCheckedChange = {
                                hideBlueTicks = it
                                config?.let { c -> viewModel.updateLegendConfig(c.copy(hideBlueTicks = it)) }
                            }
                        )

                        HorizontalDivider(color = DividerColor, modifier = Modifier.padding(vertical = 10.dp))

                        FeatureSwitchRow(
                            title = "إخفاء صح الاستلام الثاني",
                            subtitle = "يظهر للطرف الآخر صح واحد فقط بأنك غير متصل",
                            icon = Icons.Default.Check,
                            checked = hideSecondTick,
                            onCheckedChange = {
                                hideSecondTick = it
                                config?.let { c -> viewModel.updateLegendConfig(c.copy(hideSecondTick = it)) }
                            }
                        )
                    }
                }
            }

            // Section 2: Smart Auto Reply
            item {
                Text(
                    text = "🤖 الرد التلقائي الذكي",
                    color = LegendGoldBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        FeatureSwitchRow(
                            title = "تفعيل المجيب الآلي التلقائي",
                            subtitle = "رد تلقائي فوري عند انشغالك أو عدم توفرك",
                            icon = Icons.Default.AutoMode,
                            checked = autoReply,
                            onCheckedChange = {
                                autoReply = it
                                config?.let { c -> viewModel.updateLegendConfig(c.copy(autoReplyEnabled = it)) }
                            }
                        )

                        if (autoReply) {
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = autoReplyText,
                                onValueChange = {
                                    autoReplyText = it
                                    config?.let { c -> viewModel.updateLegendConfig(c.copy(autoReplyText = it)) }
                                },
                                label = { Text("نص الرد التلقائي", color = LegendGold) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = CardSurfaceElevated,
                                    unfocusedContainerColor = CardSurfaceElevated,
                                    focusedBorderColor = LegendGold,
                                    unfocusedBorderColor = DividerColor,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )
                        }
                    }
                }
            }

            // Section 3: Themes & Customization
            item {
                Text(
                    text = "🎨 الثيمات والتخصيص الملكي",
                    color = LegendGoldBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = null,
                                tint = LegendGoldBright,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الثيم الملكي الحصري (الأزرق والذهبي)",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "الثيم الأيقوني المخصص لـ 'الاسطورة محمد' مفعل",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                            Text(
                                text = "مفعّل 👑",
                                color = LegendGoldBright,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Section 4: Lock
            item {
                Text(
                    text = "🔒 قفل الأمان والبصمة",
                    color = LegendGoldBright,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        FeatureSwitchRow(
                            title = "قفل واتساب الاسطورة برمز سري",
                            subtitle = "حماية فورية عند فتح التطبيق والمحادثات",
                            icon = Icons.Default.Lock,
                            checked = securityLock,
                            onCheckedChange = {
                                securityLock = it
                                config?.let { c -> viewModel.updateLegendConfig(c.copy(securityLockEnabled = it)) }
                            }
                        )
                    }
                }
            }

            // Bottom space
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun FeatureSwitchRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(RoyalBlueMedium)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = LegendGoldBright,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 11.sp
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = RoyalNavyDark,
                checkedTrackColor = LegendGoldBright,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = CardSurfaceElevated
            )
        )
    }
}
