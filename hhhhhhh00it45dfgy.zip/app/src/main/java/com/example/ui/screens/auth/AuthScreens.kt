package com.example.ui.screens.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.LegendAvatar
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.DividerColor
import com.example.ui.theme.LegendGold
import com.example.ui.theme.LegendGoldBright
import com.example.ui.theme.LegendGoldDark
import com.example.ui.theme.LegendGoldLight
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueAccent
import com.example.ui.theme.RoyalBlueMedium
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun WelcomeAuthScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RoyalNavyDark)
            .padding(24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            // Crown Logo with glowing border
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(LegendGoldBright, RoyalBlueMedium, RoyalNavyDark)
                        )
                    )
                    .border(3.dp, LegendGold, CircleShape)
                    .shadow(16.dp, CircleShape, spotColor = LegendGoldBright)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_app_icon),
                    contentDescription = "شعار الاسطورة",
                    modifier = Modifier.size(80.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "واتساب الاسطورة محمد",
                color = LegendGoldBright,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "الإصدار الملكي الفاخر للمراسلة الفورية والمكالمات",
                color = RoyalBlueAccent,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Features highlights card
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, LegendGold.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    FeatureHighlightRow("🔒 تشفير تام فائق الأمان ومكالمات بدقة HD")
                    Spacer(modifier = Modifier.height(8.dp))
                    FeatureHighlightRow("👑 ميزات إضافية: عدم حذف الرسائل وتجميد الظهور")
                    Spacer(modifier = Modifier.height(8.dp))
                    FeatureHighlightRow("🎨 ثيمات مخصصة بالأزرق الملكي والذهبي الفاخر")
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Agree and continue button
            Button(
                onClick = { viewModel.navigateTo(AppScreen.AUTH_PHONE) },
                colors = ButtonDefaults.buttonColors(containerColor = LegendGold),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_agree_continue")
            ) {
                Text(
                    text = "الموافقة والمتابعة 👑",
                    color = RoyalNavyDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun PhoneLoginScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    var countryCode by remember { mutableStateOf("+966") }
    var phoneNumber by remember { mutableStateOf("501234567") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RoyalNavyDark)
            .padding(24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize().padding(top = 40.dp)
        ) {
            Text(
                text = "أدخل رقم هاتفك",
                color = LegendGoldBright,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "سيقوم واتساب الاسطورة محمد بالتحقق من رقمك لحماية حسابك الملكي",
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Country Selector (Display)
            Surface(
                color = CardSurfaceDark,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DividerColor, RoundedCornerShape(12.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text(
                        text = "المملكة العربية السعودية (أو اختر دولتك)",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Text(text = "🇸🇦", fontSize = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Phone Input
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = CardSurfaceDark,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .width(90.dp)
                        .border(1.dp, DividerColor, RoundedCornerShape(12.dp))
                ) {
                    OutlinedTextField(
                        value = countryCode,
                        onValueChange = { countryCode = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedBorderColor = LegendGold,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = LegendGoldBright,
                            unfocusedTextColor = LegendGoldBright
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Surface(
                    color = CardSurfaceDark,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, DividerColor, RoundedCornerShape(12.dp))
                ) {
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { phoneNumber = it },
                        placeholder = { Text("رقم الهاتف", color = TextMuted) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_phone_number"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedBorderColor = LegendGold,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { viewModel.navigateTo(AppScreen.AUTH_OTP) },
                colors = ButtonDefaults.buttonColors(containerColor = LegendGold),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_next_otp")
            ) {
                Text(
                    text = "التالي",
                    color = RoyalNavyDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun OtpVerificationScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    var otpCode by remember { mutableStateOf("777777") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(RoyalNavyDark)
            .padding(24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize().padding(top = 40.dp)
        ) {
            Text(
                text = "رمز التحقق الملكي 🔑",
                color = LegendGoldBright,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "تم إرسال رمز الأمان المكون من 6 أرقام عبر SMS",
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // OTP Input Field
            OutlinedTextField(
                value = otpCode,
                onValueChange = { if (it.length <= 6) otpCode = it },
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = LegendGoldBright,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    letterSpacing = 8.sp
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_otp_code"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardSurfaceDark,
                    unfocusedContainerColor = CardSurfaceDark,
                    focusedBorderColor = LegendGold,
                    unfocusedBorderColor = DividerColor
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "إعادة إرسال الرمز خلال 0:45",
                color = RoyalBlueAccent,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { viewModel.navigateTo(AppScreen.HOME) },
                colors = ButtonDefaults.buttonColors(containerColor = LegendGold),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_verify_confirm")
            ) {
                Text(
                    text = "دخول إلى واتساب الاسطورة 👑",
                    color = RoyalNavyDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun FeatureHighlightRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = LegendGoldBright,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = text,
            color = TextPrimary,
            fontSize = 12.sp,
            lineHeight = 16.sp
        )
    }
}
