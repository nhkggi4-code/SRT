package com.example.ui.screens.group

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.LegendAvatar
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.DividerColor
import com.example.ui.theme.LegendGold
import com.example.ui.theme.LegendGoldBright
import com.example.ui.theme.LegendGoldDark
import com.example.ui.theme.LegendGoldLight
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueAccent
import com.example.ui.theme.RoyalBlueMedium
import com.example.ui.theme.RoyalNavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TopBarSurface
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.ChatViewModel

data class DummyContact(
    val id: String,
    val name: String,
    val phone: String,
    val avatarRes: Int? = null,
    val status: String = "متاح على واتساب الاسطورة"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewGroupScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    var groupName by remember { mutableStateOf("") }
    val contacts = remember {
        listOf(
            DummyContact("1", "الاسطورة محمد 👑", "+966 55 000 0001", R.drawable.img_legend_avatar, "المطور وصاحب الإصدار الملكي 👑"),
            DummyContact("2", "المهندس أحمد التقني", "+966 50 111 2233", null, "مطور برمجيات ونظم 💻"),
            DummyContact("3", "د. سارة المنصور", "+966 54 888 9900", null, "أمن المعلومات والسيبراني 🛡️"),
            DummyContact("4", "م. فيصل الشمري", "+966 53 222 3344", null, "عضو مجتمع أساطير العرب 🌟"),
            DummyContact("5", "الأستاذ خالد العتيبي", "+966 56 333 4455", null, "متاح للمكالمات والاستفسار"),
            DummyContact("6", "عبدالله القحطاني", "+966 59 777 6655", null, "سبحان الله وبحمده سبحان الله العظيم")
        )
    }
    val selectedContactIds = remember { mutableStateListOf("1", "2") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "مجموعة أساطير جديدة 👑",
                            color = LegendGoldBright,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Text(
                            text = "تم اختيار ${selectedContactIds.size} من الأعضاء",
                            color = RoyalBlueAccent,
                            fontSize = 12.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.HOME) },
                        modifier = Modifier.testTag("btn_back_from_new_group")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = LegendGoldBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TopBarSurface)
            )
        },
        floatingActionButton = {
            if (groupName.isNotBlank() && selectedContactIds.isNotEmpty()) {
                FloatingActionButton(
                    onClick = {
                        viewModel.createGroup(groupName, selectedContactIds.size + 1)
                    },
                    containerColor = LegendGold,
                    contentColor = RoyalNavyDark,
                    shape = CircleShape,
                    modifier = Modifier.testTag("btn_confirm_create_group")
                ) {
                    Icon(imageVector = Icons.Default.Done, contentDescription = "إنشاء المجموعة")
                }
            }
        },
        containerColor = RoyalNavyDark,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(bottom = 80.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(RoyalNavyDark)
        ) {
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(LegendGold, RoyalBlueMedium)
                                    )
                                )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = RoyalNavyDark,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        OutlinedTextField(
                            value = groupName,
                            onValueChange = { groupName = it },
                            placeholder = { Text("اكتب اسم المجموعة الملكية...", color = TextMuted) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_group_name"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CardSurfaceDark,
                                unfocusedContainerColor = CardSurfaceDark,
                                focusedBorderColor = LegendGold,
                                unfocusedBorderColor = DividerColor,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "اختر جهات الاتصال للانضمام للمجموعة:",
                        color = LegendGoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            items(contacts, key = { it.id }) { contact ->
                val isSelected = selectedContactIds.contains(contact.id)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (isSelected) selectedContactIds.remove(contact.id)
                            else selectedContactIds.add(contact.id)
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    LegendAvatar(
                        name = contact.name,
                        avatarRes = contact.avatarRes,
                        size = 50.dp,
                        isVip = contact.name.contains("الاسطورة")
                    )

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = contact.name,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = contact.status,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = {
                            if (isSelected) selectedContactIds.remove(contact.id)
                            else selectedContactIds.add(contact.id)
                        },
                        colors = CheckboxDefaults.colors(
                            checkedColor = LegendGold,
                            checkmarkColor = RoyalNavyDark,
                            uncheckedColor = TextMuted
                        )
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    var contactName by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "محادثة جديدة برقم 💬",
                        color = LegendGoldBright,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.HOME) },
                        modifier = Modifier.testTag("btn_back_new_chat")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = LegendGoldBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TopBarSurface)
            )
        },
        containerColor = RoyalNavyDark,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(RoyalNavyDark)
                .padding(20.dp)
        ) {
            Text(
                text = "مراسلة مباشرة بدون حفظ الرقم",
                color = LegendGoldBright,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "ابدأ محادثة ملكية مشفرة فوراً بإدخال الاسم ورقم الهاتف",
                color = TextSecondary,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = contactName,
                onValueChange = { contactName = it },
                label = { Text("اسم الشخص أو جهة الاتصال", color = LegendGold) },
                placeholder = { Text("مثال: عبدالمحسن", color = TextMuted) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_new_chat_name"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardSurfaceDark,
                    unfocusedContainerColor = CardSurfaceDark,
                    focusedBorderColor = LegendGold,
                    unfocusedBorderColor = DividerColor,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { phoneNumber = it },
                label = { Text("رقم الهاتف (مع مفتاح الدولة)", color = LegendGold) },
                placeholder = { Text("+966 5X XXX XXXX", color = TextMuted) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_new_chat_phone"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardSurfaceDark,
                    unfocusedContainerColor = CardSurfaceDark,
                    focusedBorderColor = LegendGold,
                    unfocusedBorderColor = DividerColor,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    val name = if (contactName.isNotBlank()) contactName else phoneNumber
                    if (name.isNotBlank()) {
                        viewModel.createChat(name, phoneNumber)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = LegendGold),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_start_direct_chat")
            ) {
                Text(
                    text = "بدء المحادثة الملكية 💬",
                    color = RoyalNavyDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}
